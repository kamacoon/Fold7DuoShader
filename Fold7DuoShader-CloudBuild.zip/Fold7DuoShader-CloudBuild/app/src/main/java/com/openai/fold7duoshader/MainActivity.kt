package com.openai.fold7duoshader

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.*
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var duoView: DuoTransitionView
    private lateinit var hinge: HingeAngleController
    private lateinit var overlay: LinearLayout
    private lateinit var status: TextView
    private var manualProgress = 0f

    private val coverFile by lazy { File(filesDir, "cover_screen.png") }
    private val innerFile by lazy { File(filesDir, "inner_screen.png") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        hideBars()

        val root = FrameLayout(this)
        duoView = DuoTransitionView(this)
        root.addView(duoView, FrameLayout.LayoutParams(-1, -1))

        overlay = makeOverlay()
        root.addView(overlay, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        val gear = Button(this).apply {
            text = "⚙"
            textSize = 20f
            alpha = 0.72f
            setOnClickListener {
                val nextVisibility = if (overlay.getVisibility() == View.VISIBLE) View.GONE else View.VISIBLE
                overlay.setVisibility(nextVisibility)
            }
        }
        root.addView(gear, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(18); marginEnd = dp(12)
        })

        setContentView(root)
        loadSavedImages()

        hinge = HingeAngleController(this) { angle, p ->
            manualProgress = p
            duoView.setProgress(p)
            status.text = "HINGE %.1f°   %.0f%%   %s".format(angle, p * 100f, if (duoView.inferredInner()) "INNER" else "COVER")
        }
        status.text = if (hinge.available) "센서: ${hinge.sensorName}" else "힌지 센서 미감지 · 아래 슬라이더로 테스트"
    }

    override fun onResume() { super.onResume(); hideBars(); hinge.start() }
    override fun onPause() { hinge.stop(); super.onPause() }

    private fun makeOverlay(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(18))
            setBackgroundColor(Color.argb(188, 12, 12, 14))

            status = TextView(this@MainActivity).apply { setTextColor(Color.WHITE); textSize = 13f }
            addView(status)

            addView(SeekBar(this@MainActivity).apply {
                max = 1000
                progress = 0
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, v: Int, fromUser: Boolean) {
                        if (fromUser) { manualProgress = v / 1000f; duoView.setProgress(manualProgress) }
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                    override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
                })
            })

            val row1 = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            row1.addView(button("커버 캡처 선택") { pickImage(REQ_COVER) }, LinearLayout.LayoutParams(0, -2, 1f))
            row1.addView(button("내부 캡처 선택") { pickImage(REQ_INNER) }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(row1)

            val row2 = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            row2.addView(button("현재=접힘") { hinge.markClosed() }, LinearLayout.LayoutParams(0, -2, 1f))
            row2.addView(button("현재=펼침") { hinge.markOpen() }, LinearLayout.LayoutParams(0, -2, 1f))
            row2.addView(button("방향 반전") { hinge.toggleInvert() }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(row2)

            val row3 = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            row3.addView(button("자동 화면판별") { duoView.setForceInner(null) }, LinearLayout.LayoutParams(0, -2, 1f))
            row3.addView(button("커버 강제") { duoView.setForceInner(false) }, LinearLayout.LayoutParams(0, -2, 1f))
            row3.addView(button("내부 강제") { duoView.setForceInner(true) }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(row3)

            addView(TextView(this@MainActivity).apply {
                setTextColor(Color.LTGRAY)
                textSize = 11f
                text = "아이폰 Duo처럼: 커버 UI를 힌지쪽에 고정 → 펼치며 투과/블러 → 내부 UI가 늦게 선명해짐. 실제 SystemUI 교체가 아닌 센서+스크린샷 셰이더 데모입니다."
            })
        }
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; setOnClickListener { action() }
    }

    private fun pickImage(req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(i, req)
    }

    @Deprecated("legacy picker for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
        if (requestCode == REQ_COVER) {
            saveBitmap(bitmap, coverFile); duoView.setCoverBitmap(bitmap)
        } else if (requestCode == REQ_INNER) {
            saveBitmap(bitmap, innerFile); duoView.setInnerBitmap(bitmap)
        }
    }

    private fun loadSavedImages() {
        if (coverFile.exists()) BitmapFactory.decodeFile(coverFile.absolutePath)?.let(duoView::setCoverBitmap)
        if (innerFile.exists()) BitmapFactory.decodeFile(innerFile.absolutePath)?.let(duoView::setInnerBitmap)
    }

    private fun saveBitmap(bitmap: Bitmap, file: File) {
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    private fun hideBars() {
        window.insetsController?.apply {
            hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
            systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQ_COVER = 101
        private const val REQ_INNER = 102
    }
}
