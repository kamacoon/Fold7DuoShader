package com.openai.fold7duoshader

import android.content.Context
import android.graphics.*
import android.os.Build
import android.view.View
import kotlin.math.max

class DuoTransitionView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var coverBitmap: Bitmap = makeDemoBitmap(1080, 2400, false)
    private var innerBitmap: Bitmap = makeDemoBitmap(2208, 1840, true)
    private var coverShader = BitmapShader(coverBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    private var innerShader = BitmapShader(innerBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    private var progress = 0f
    private var forceInner: Boolean? = null

    private val runtimeShader = RuntimeShader(AGSL)

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
        paint.shader = runtimeShader
    }

    fun setProgress(p: Float) {
        progress = p.coerceIn(0f, 1f)
        invalidate()
    }

    fun setCoverBitmap(bitmap: Bitmap) {
        coverBitmap = bitmap
        coverShader = BitmapShader(coverBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        invalidate()
    }

    fun setInnerBitmap(bitmap: Bitmap) {
        innerBitmap = bitmap
        innerShader = BitmapShader(innerBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        invalidate()
    }

    fun setForceInner(value: Boolean?) {
        forceInner = value
        invalidate()
    }

    fun inferredInner(): Boolean = forceInner ?: (width > 0 && height > 0 && width.toFloat() / height.toFloat() > 0.64f)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val innerMode = inferredInner()
        configureShaderMatrices(innerMode)
        runtimeShader.setInputShader("coverTex", coverShader)
        runtimeShader.setInputShader("innerTex", innerShader)
        runtimeShader.setFloatUniform("resolution", width.toFloat(), height.toFloat())
        runtimeShader.setFloatUniform("progress", progress)
        runtimeShader.setFloatUniform("innerMode", if (innerMode) 1f else 0f)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }

    private fun configureShaderMatrices(innerMode: Boolean) {
        val innerM = centerCropMatrix(innerBitmap, RectF(0f, 0f, width.toFloat(), height.toFloat()))
        innerShader.setLocalMatrix(innerM)

        val coverDst = if (innerMode) {
            // The Duo effect keeps the cover UI spatially anchored to the hinge-side/right page.
            RectF(width * 0.50f, 0f, width.toFloat(), height.toFloat())
        } else {
            RectF(0f, 0f, width.toFloat(), height.toFloat())
        }
        val coverM = centerCropMatrix(coverBitmap, coverDst)
        coverShader.setLocalMatrix(coverM)
    }

    private fun centerCropMatrix(bitmap: Bitmap, dst: RectF): Matrix {
        val srcW = bitmap.width.toFloat()
        val srcH = bitmap.height.toFloat()
        val scale = max(dst.width() / srcW, dst.height() / srcH)
        val outW = srcW * scale
        val outH = srcH * scale
        val left = dst.left + (dst.width() - outW) * 0.5f
        val top = dst.top + (dst.height() - outH) * 0.5f
        return Matrix().apply {
            setScale(scale, scale)
            postTranslate(left, top)
        }
    }

    companion object {
        private const val AGSL = """
            uniform shader coverTex;
            uniform shader innerTex;
            uniform float2 resolution;
            uniform float progress;
            uniform float innerMode;

            half4 blurCover(float2 p, float r) {
                half4 c = coverTex.eval(p) * 0.24;
                c += coverTex.eval(p + float2(r, 0.0)) * 0.12;
                c += coverTex.eval(p - float2(r, 0.0)) * 0.12;
                c += coverTex.eval(p + float2(0.0, r)) * 0.12;
                c += coverTex.eval(p - float2(0.0, r)) * 0.12;
                c += coverTex.eval(p + float2(r * 0.7, r * 0.7)) * 0.07;
                c += coverTex.eval(p + float2(-r * 0.7, r * 0.7)) * 0.07;
                c += coverTex.eval(p + float2(r * 0.7, -r * 0.7)) * 0.07;
                c += coverTex.eval(p + float2(-r * 0.7, -r * 0.7)) * 0.07;
                return c;
            }

            half4 blurInner(float2 p, float r) {
                half4 c = innerTex.eval(p) * 0.24;
                c += innerTex.eval(p + float2(r, 0.0)) * 0.12;
                c += innerTex.eval(p - float2(r, 0.0)) * 0.12;
                c += innerTex.eval(p + float2(0.0, r)) * 0.12;
                c += innerTex.eval(p - float2(0.0, r)) * 0.12;
                c += innerTex.eval(p + float2(r * 0.7, r * 0.7)) * 0.07;
                c += innerTex.eval(p + float2(-r * 0.7, r * 0.7)) * 0.07;
                c += innerTex.eval(p + float2(r * 0.7, -r * 0.7)) * 0.07;
                c += innerTex.eval(p + float2(-r * 0.7, -r * 0.7)) * 0.07;
                return c;
            }

            half4 main(float2 p) {
                float t = clamp(progress, 0.0, 1.0);
                float openEase = t * t * (3.0 - 2.0 * t);

                if (innerMode < 0.5) {
                    // Cover display: UI remains fixed to the glass, then progressively blurs/darkens.
                    float blurT = smoothstep(0.12, 0.78, t);
                    float r = 0.5 + 24.0 * blurT;
                    float2 center = resolution * 0.5;
                    float scale = 1.0 + 0.025 * blurT;
                    float2 q = center + (p - center) / scale;
                    half4 col = blurCover(q, r);
                    float dark = smoothstep(0.48, 0.98, t) * 0.88;
                    col.rgb *= half(1.0 - dark);
                    return col;
                }

                // Inner display: the cover UI is pinned to the hinge-side/right half.
                // The new left page arrives blurred, while the old content looks "see-through".
                float seam = resolution.x * 0.5;
                float rightMask = smoothstep(seam - 4.0, seam + 4.0, p.x);

                // Apple-like sequencing: geometry settles before the incoming UI becomes fully sharp.
                float reveal = smoothstep(0.10, 0.74, openEase);
                float sharpen = smoothstep(0.54, 1.00, openEase);
                float innerBlur = 34.0 * (1.0 - sharpen) + 0.35;
                float coverBlur = 4.0 + 30.0 * smoothstep(0.18, 0.86, openEase);

                // Slight parallax only on the incoming layer; the anchored cover layer does not jump.
                float parallax = (1.0 - reveal) * resolution.x * 0.035;
                float2 innerP = p + float2(parallax * (1.0 - rightMask), 0.0);

                half4 incoming = blurInner(innerP, innerBlur);
                half4 anchored = blurCover(p, coverBlur);

                float leftReveal = smoothstep(0.08, 0.68, openEase);
                half4 leftSide = incoming;
                leftSide.rgb *= half(0.30 + 0.70 * leftReveal);
                leftSide.a *= half(leftReveal);

                // Right page transitions later so icons appear to remain in the same physical place.
                float rightCross = smoothstep(0.34, 0.94, openEase);
                half4 rightSide = mix(anchored, incoming, half(rightCross));

                half4 col = mix(leftSide, rightSide, half(rightMask));

                // Soft moving blur/shadow boundary around the hinge, not a fake black crease.
                float boundaryWidth = mix(120.0, 18.0, reveal);
                float boundary = 1.0 - smoothstep(0.0, boundaryWidth, abs(p.x - seam));
                col.rgb *= half(1.0 - 0.20 * boundary * (1.0 - sharpen));

                // Final sharpening continues after most of the spatial transition has settled.
                float finalFade = smoothstep(0.88, 1.0, openEase);
                half4 crisp = innerTex.eval(p);
                col = mix(col, crisp, half(finalFade));
                return col;
            }
        """

        private fun makeDemoBitmap(w: Int, h: Int, inner: Boolean): Bitmap {
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(b)
            val bg = Paint(Paint.ANTI_ALIAS_FLAG)
            val shader = LinearGradient(
                0f, 0f, w.toFloat(), h.toFloat(),
                intArrayOf(Color.rgb(25, 34, 64), Color.rgb(105, 78, 145), Color.rgb(235, 165, 125)),
                null, Shader.TileMode.CLAMP
            )
            bg.shader = shader
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(210, 255, 255, 255) }
            val cols = if (inner) 7 else 4
            val rows = if (inner) 5 else 6
            val marginX = w * 0.09f
            val marginY = h * 0.16f
            val usableW = w - marginX * 2
            val stepX = usableW / (cols - 1).coerceAtLeast(1)
            val stepY = (h * 0.48f) / (rows - 1).coerceAtLeast(1)
            val r = w / if (inner) 28f else 15f
            for (row in 0 until rows) for (col in 0 until cols) {
                c.drawRoundRect(
                    marginX + col * stepX - r,
                    marginY + row * stepY - r,
                    marginX + col * stepX + r,
                    marginY + row * stepY + r,
                    r * 0.38f, r * 0.38f, p
                )
            }
            return b
        }
    }
}
