package com.openai.fold7duoshader

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs

class HingeAngleController(
    context: Context,
    private val onUpdate: (angle: Float, progress: Float) -> Unit
) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val prefs = context.getSharedPreferences("hinge", Context.MODE_PRIVATE)
    private val standard = sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
    private val fallback = sensorManager.getSensorList(Sensor.TYPE_ALL).firstOrNull {
        val s = (it.name + " " + it.stringType).lowercase()
        ("hinge" in s || "fold" in s || "lid" in s) && "angle" in s
    }
    private val sensor = standard ?: fallback

    private var smoothed = Float.NaN
    private var closed = prefs.getFloat("closed", 0f)
    private var opened = prefs.getFloat("opened", 180f)
    private var invert = prefs.getBoolean("invert", false)
    var lastRaw: Float = Float.NaN
        private set

    val available: Boolean get() = sensor != null
    val sensorName: String get() = sensor?.name ?: "hinge sensor not found"

    fun start() {
        sensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    fun stop() = sensorManager.unregisterListener(this)

    override fun onSensorChanged(event: SensorEvent) {
        val raw = event.values.firstOrNull() ?: return
        if (!raw.isFinite()) return
        lastRaw = raw
        smoothed = if (smoothed.isFinite()) smoothed + (raw - smoothed) * 0.46f else raw
        val span = opened - closed
        var p = if (abs(span) < 0.1f) 0f else ((smoothed - closed) / span).coerceIn(0f, 1f)
        if (invert) p = 1f - p
        onUpdate(raw, p)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    fun markClosed() {
        if (!lastRaw.isFinite()) return
        closed = lastRaw
        prefs.edit().putFloat("closed", closed).apply()
    }

    fun markOpen() {
        if (!lastRaw.isFinite()) return
        opened = lastRaw
        prefs.edit().putFloat("opened", opened).apply()
    }

    fun toggleInvert(): Boolean {
        invert = !invert
        prefs.edit().putBoolean("invert", invert).apply()
        return invert
    }
}
