plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.openai.fold7duoshader"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.openai.fold7duoshader"
        minSdk = 33
        targetSdk = 35
        versionCode = 2
        versionName = "0.2-duo-shader"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
