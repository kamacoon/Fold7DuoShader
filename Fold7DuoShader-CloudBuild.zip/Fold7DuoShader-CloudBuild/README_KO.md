# Fold7 Duo Shader

이 버전은 이전의 커스텀 런처 morph 방식이 아니라, iPhone Duo 전환을 Fold 8에서 재현한 공개 PoC와 같은 방향의 **힌지 센서 + 고정 스크린샷 + GPU 셰이더** 데모입니다.

핵심 동작:
- 외부 UI를 힌지 쪽/오른쪽 페이지에 고정
- 펼침 초반부터 외부 UI에 점진적 블러/암전
- 내부 UI는 왼쪽에서 블러 상태로 들어오고, 공간 전환이 대부분 끝난 뒤 선명해짐
- 힌지 경계에는 검은 선 대신 부드러운 경계 음영
- 실제 Fold7 힌지 각도가 애니메이션 진행률을 직접 제어
- 사용자의 커버/내부 홈 스크린샷 2장을 선택 가능

제약:
- 삼성 SystemUI 자체를 대체하지 않습니다.
- 일반 앱 위에 시스템 수준으로 이 애니메이션을 적용할 수 없습니다.
- 앱을 열어둔 상태에서 보는 proof-of-concept입니다.

## GitHub Actions 빌드
저장소 루트에 이 파일들을 올린 뒤 Actions > Build Fold7 Duo Shader APK > Run workflow.
성공 후 Artifacts의 `Fold7DuoShader-debug-apk`를 받아 압축을 풀고 `app-debug.apk` 설치.
